import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
@Component({
  selector: 'addprojet',
  templateUrl: './addprojet.component.html',
  styleUrls: ['./addprojet.component.scss']
})
export class AddprojetComponent implements OnInit, OnDestroy {
  form: FormGroup;

  // Horizontal Stepper
  horizontalStepperStep1: FormGroup;
  horizontalStepperStep2: FormGroup;
  horizontalStepperStep3: FormGroup;

  // Vertical Stepper
  verticalStepperStep1: FormGroup;
  verticalStepperStep2: FormGroup;
  verticalStepperStep3: FormGroup;

  // Private
  private _unsubscribeAll: Subject<any>;

  constructor(
    private _formBuilder: FormBuilder
  ) { }

  ngOnInit():void {
    this.form = this._formBuilder.group({
    
      NomProjet :['', Validators.required],
      NbreTache : ['', Validators.required],
      lastName  : ['', Validators.required],
      Description   : ['', Validators.required],
      DateDebut  : ['', Validators.required],
      DateFin      : ['', Validators.required],
      Hsupp     : ['', Validators.required],
      client: ['', [Validators.required, Validators.maxLength(5)]],
      country   : ['', Validators.required]
  });
    this._unsubscribeAll = new Subject();
  }
  ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }

}
