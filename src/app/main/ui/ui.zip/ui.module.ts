import { NgModule } from '@angular/core';

import { UIFormsModule } from 'app/main/ui/forms/forms.module';
import { UIProjetsModule } from 'app/main/ui/projets/projets.module';

@NgModule({
    imports: [
      
        UIFormsModule,
        UIProjetsModule
      
    ],
    declarations: []
})
export class UIModule
{
}
